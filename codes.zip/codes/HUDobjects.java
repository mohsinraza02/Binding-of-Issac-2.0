package codes;

public class HUDobjects extends Entities {

	public HUDobjects(int x, int y, int w, int h, String image) {
		super(x, y, w, h, "HUD", image);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getDesc() {
		// TODO Auto-generated method stub
		return null;
	}

}
